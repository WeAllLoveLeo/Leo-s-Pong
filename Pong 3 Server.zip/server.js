const WebSocket = require('ws');
const server = new WebSocket.Server({ port: 3000 });

let connections = [];

server.on('connection', ws => {
    connections.push(ws);

    ws.on('message', message => {
        connections.forEach(conn => {
            if (conn !== ws) conn.send(message);
        });
    });

    ws.on('close', () => {
        connections = connections.filter(conn => conn !== ws);
    });
});

console.log('Signaling server running on ws://localhost:3000');
