const canvas = document.getElementById("pongCanvas");
const ctx = canvas.getContext("2d");

// Game Variables
const paddleWidth = 10, paddleHeight = 100;
const ballSize = 10;
let leftPaddle = { x: 0, y: canvas.height / 2 - paddleHeight / 2, dy: 0 };
let rightPaddle = { x: canvas.width - paddleWidth, y: canvas.height / 2 - paddleHeight / 2, dy: 0 };
let ball = { x: canvas.width / 2, y: canvas.height / 2, dx: 4, dy: 4 };
let chickenJockeyMode = false;
let chickenJockeyPoints = 0; // Bonus points!

// AI Movement
function updateAI() {
  if (ball.y < rightPaddle.y + paddleHeight / 2) rightPaddle.dy = -5;
  else if (ball.y > rightPaddle.y + paddleHeight / 2) rightPaddle.dy = 5;
  else rightPaddle.dy = 0;
}

// Input Controls
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowUp") leftPaddle.dy = -5;
  if (e.key === "ArrowDown") leftPaddle.dy = 5;
  if (e.key === " ") chickenJockeyMode = !chickenJockeyMode; // Toggle Chicken Jockey Mode
});

document.addEventListener("keyup", (e) => {
  if (e.key === "ArrowUp" || e.key === "ArrowDown") leftPaddle.dy = 0;
});

// Game Loop
function update() {
  // Move paddles
  leftPaddle.y += leftPaddle.dy;
  rightPaddle.y += rightPaddle.dy;

  // Keep paddles within bounds
  leftPaddle.y = Math.max(Math.min(leftPaddle.y, canvas.height - paddleHeight), 0);
  rightPaddle.y = Math.max(Math.min(rightPaddle.y, canvas.height - paddleHeight), 0);

  // Move ball
  ball.x += ball.dx;
  ball.y += ball.dy;

  // Ball collisions with top and bottom
  if (ball.y < 0 || ball.y > canvas.height - ballSize) ball.dy *= -1;

  // Ball collisions with paddles
  if (
    ball.x < leftPaddle.x + paddleWidth &&
    ball.y > leftPaddle.y &&
    ball.y < leftPaddle.y + paddleHeight
  ) {
    ball.dx *= -1;
    if (chickenJockeyMode) chickenJockeyPoints += 1; // Bonus points
  }

  if (
    ball.x > rightPaddle.x - paddleWidth &&
    ball.y > rightPaddle.y &&
    ball.y < rightPaddle.y + paddleHeight
  ) {
    ball.dx *= -1;
  }

  // Ball resets when it goes out of bounds
  if (ball.x < 0 || ball.x > canvas.width) {
    ball.x = canvas.width / 2;
    ball.y = canvas.height / 2;
    ball.dx *= Math.random() > 0.5 ? 1 : -1;
    ball.dy *= Math.random() > 0.5 ? 1 : -1;
  }

  // Update AI
  updateAI();
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw paddles
  ctx.fillStyle = "white";
  ctx.fillRect(leftPaddle.x, leftPaddle.y, paddleWidth, paddleHeight);
  ctx.fillRect(rightPaddle.x, rightPaddle.y, paddleWidth, paddleHeight);

  // Draw ball
  ctx.fillStyle = chickenJockeyMode ? "yellow" : "red"; // Change ball color in Chicken Jockey Mode
  ctx.fillRect(ball.x, ball.y, ballSize, ballSize);

  // Draw Chicken Jockey Points
  ctx.fillStyle = "white";
  ctx.font = "20px Arial";
  ctx.fillText(`Chicken Jockey Points: ${chickenJockeyPoints}`, 20, 30);
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

gameLoop();